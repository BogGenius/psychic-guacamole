import { start } from './game.js';

start();
